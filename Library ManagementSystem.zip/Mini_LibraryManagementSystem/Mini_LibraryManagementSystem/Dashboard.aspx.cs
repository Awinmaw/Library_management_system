﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Mini_LibraryManagementSystem
{
    public partial class Dashboard : System.Web.UI.Page
    {

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["const"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select count(*) from BookTable", conn);
            int rowCount = (int)cmd.ExecuteScalar();
            lblGreen.Text = Convert.ToString(rowCount);

            SqlCommand cmd1 = new SqlCommand("select count(*) from BookTable where Status = 'Available'", conn);
            int rowCount1 = (int)cmd1.ExecuteScalar();
            lblBlue.Text = Convert.ToString(rowCount1);

            SqlCommand cmd2 = new SqlCommand("select count(*) from IssueBook", conn);
            int rowCount2 = (int)cmd2.ExecuteScalar();
            lblPurple.Text = Convert.ToString(rowCount2);

            SqlCommand cmd3 = new SqlCommand("select count(*) from RentBook", conn);
            int rowCount3 = (int)cmd3.ExecuteScalar();
            lblGray.Text = Convert.ToString(rowCount3);

            SqlCommand cmd4 = new SqlCommand("select count(*) from ReturnBook", conn);
            int rowCount4 = (int)cmd4.ExecuteScalar();
            lblRed.Text = Convert.ToString(rowCount4);

            SqlCommand cmd5 = new SqlCommand("select count(*) from StudentTable", conn);
            int rowCount5 = (int)cmd5.ExecuteScalar();
            lblLightblue.Text = Convert.ToString(rowCount5);

            
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            String stat1 = "Not Available";
            String stat2 = "Available";
            SqlCommand cmd1 = new SqlCommand("update BookTable set Status = @s1 from BookTable inner join IssueBook on BookTable.CodeNo = IssueBook.CodeNo", conn);
            cmd1.Parameters.AddWithValue("@s1", stat1);
            cmd1.ExecuteNonQuery();

            SqlCommand cmd2 = new SqlCommand("UPDATE BookTable SET Status = @s1 WHERE NOT EXISTS (SELECT 1 FROM IssueBook WHERE IssueBook.CodeNo = BookTable.CodeNo)", conn);
            cmd2.Parameters.AddWithValue("@s1", stat2);
            cmd2.ExecuteNonQuery();

            SqlCommand cmd3 = new SqlCommand("update BookTable set Status = @s3 from BookTable inner join RentBook on BookTable.CodeNo = RentBook.CodeNo", conn);
            cmd3.Parameters.AddWithValue("@s3", stat1);
            cmd3.ExecuteNonQuery();

            SqlCommand cmd4 = new SqlCommand("update BookTable set Status = @s4 from BookTable inner join ReturnBook on BookTable.CodeNo = ReturnBook.CodeNo", conn);
            cmd3.Parameters.AddWithValue("@s4", stat2);
            cmd3.ExecuteNonQuery();
        }

    }
}